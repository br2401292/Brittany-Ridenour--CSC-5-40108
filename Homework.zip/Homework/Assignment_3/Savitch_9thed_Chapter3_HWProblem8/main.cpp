/* 
  File:   main.cpp
  Author: Dr. Mark E. Lehr
  Created on January 3, 2017, 12:15 PM
  Purpose:  Template to be used in all programming
            projects!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int beg_hr, beg_min,end_hr, end_min, total_hr, total_min, total_due;
    char day, ans;
    
    //Input value
    
    //Process by mapping inputs to outputs
   
   cout<<"Please enter the beginning hour and minute:\n";
   cin>>beg_hr>>beg_min;
   cout<<"Please enter the ending hour and minute:\n";
   cin>>end_hr>>end_min;
   cout<<"Please enter the day of the week:\n";
   cin>>day;
   switch (day){
       case 'su':
           total_hr=end_hr-beg_hr;
           total_min=(end_min-beg_min);
           total_due=0.15*(total_min+(total_hr*60));
           cout<<"The total cost is $"<<total_due;
           break;
       case 'sa':
           total_hr=end_hr-beg_hr;
           total_min=(end_min-beg_min);
           total_due=0.15*(total_min+(total_hr*60));
           cout<<"The total cost is $"<<total_due;
           break;
           
       default:
           if (beg_hr>=8 && beg_hr<=18){
           total_hr=end_hr-beg_hr;
           total_min=(end_min-beg_min);
           total_due=0.40*(total_min+(total_hr*60));
           cout<<"The total cost is $"<<total_due; 
           }
           else if (beg_hr<8 || beg_hr>18){
           total_hr=end_hr-beg_hr;
           total_min=(end_min-beg_min);
           total_due=0.25*(total_min+(total_hr*60));
           cout<<"The total cost is $"<<total_due;
           }
           break;
   }
    //Output values

    //Exit stage right!
    return 0;
}