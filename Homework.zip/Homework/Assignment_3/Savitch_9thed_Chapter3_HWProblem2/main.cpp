/* 
  File:  Chapter 3 HW Problem 2
  Author: Brittany Ridenour
  Created on January 16, 2017, 4:56 PM
  Purpose:  User inputs and account balance and program will output the 
 * interest due, total amt due, and minimum payment.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double acctbal, int_due, min_pay;
    const double total_due=int_due+acctbal;
    char ans;
    
    //Input values

   
    //Process by mapping inputs to outputs
    do
    {
        cout<< "Please enter your account balance: $";
        cin>> acctbal;
        int_due=(0.015*1000.00)+(0.010*(acctbal-1000.00));
        
        if (total_due>10.00) {
            min_pay=0.10*total_due;
        }
        else {
                min_pay=total_due;
        }
        cout<< " Your total amout due is $"<<total_due<<" and your interest due ";
        cout<<"is $"<<int_due<<". Your payment has a minimum of $"<<min_pay<<".\n";
        cout<< "Would you like to enter another account balance?";
        cin>> ans;
    } while (ans=='y'||ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}