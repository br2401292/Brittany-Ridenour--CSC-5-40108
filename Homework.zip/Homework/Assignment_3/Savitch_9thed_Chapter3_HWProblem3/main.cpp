/* 
  File:  Chapter 3 HW Problem 3
  Author: Brittany Ridenour
  Created on January 16, 2017, 5:40 PM
  Purpose:  User enters their birthday and program outputs the sign and 
 * horoscope. Also notifies is user's birthday is on a cusp.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int month, day;
    char ans;
    //Input values
    
    //Process by mapping inputs to outputs
    do{
        cout<< "Please enter your birth month:\n";
        cin>>month;
        cout<< "Please enter your birth day:\n";
        cin>>day;
        switch (month){
            case 1:
                if (day<19){
                    cout<< "You are a Capricorn!\n";
                    cout<< "Capricorn horoscope...\n";
                }
                else if (day==19||day==20){
                    cout<<"You are on the cusp, you can be either a Capricorn ";
                    cout<<"or an Aquarius.\n";
                    cout<<" Capricorn horoscope...\n";
                    cout<<"Aquarius horoscope...\n";
                }
                else if (day>20){
                    cout<<"You are an Aquarius!\n";
                    cout<<"Aquarius horoscope...\n";
                }
                break;
            case 2:
                if (day<18){
                    cout<<"You are an Aquarius!\n";
                    cout<<"Aquarius horoscope...\n";
                }
                else if (day==18||day==19){
                    cout<<"You are on the cusp, you can be either an Aquarius or ";
                    cout<<"a Pisces.\n";
                    cout<<"Aquarius horoscope...\n";
                    cout<<"Pisces horoscope...\n";
                }
                else if (day>19){
                    cout<<"You are a Pisces!\n";
                    cout<<"Pisces horoscope...\n";
                }
                break;
            case 3:
                if (day<20){
                    cout<<"You are a Pisces!\n";
                    cout<<"Pisces horoscope...\n";
                }
                else if (day==20||day==21){
                    cout<<"You are on the cusp, you can be either a Pisces or ";
                    cout<<"an Aries.\n";
                    cout<<"Pisces horoscope...\n";
                    cout<<"Aries horoscope...\n";
                }
                else if (day>21){
                    cout<<"You are an Aries!\n";
                    cout<<"Aries horoscope...\n";
                }
                break;
            case 4:
                if (day<19){
                    cout<<"You are an Aries!\n";
                    cout<<"Aries horoscope...\n";
                }
                else if (day==19||day==20){
                    cout<<"You are on the cusp, you can be either Aries or Taurus.\n";
                    cout<<"Aries horoscope...\n";
                    cout<<"Taurus horoscope...\n";
                }
                else if (day>20){
                    cout<<"You are an Taurus!\n";
                    cout<<"Taurus horoscope...\n";
                }
                break;
            case 5:
                if (day<20){
                    cout<<"You are a Taurus!\n";
                    cout<<"Taurus horoscope...\n";
                }
                else if (day==20||day==21){
                    cout<<"You are on the cusp, you can be either Taurus or Gemini.\n";
                    cout<<"Taurus horoscope...\n";
                    cout<<"Gemini horoscope...\n";
                }
                else if (day>21){
                    cout<<"You are a Gemini!\n";
                    cout<<"Gemini horoscope...\n";
                }
                break;
            case 6:
                if (day<21){
                    cout<<"You are a Gemini!\n";
                    cout<<"Aquarius horoscope...\n";
                }
                else if (day==21||day==22){
                    cout<<"You are on the cusp, you can be either Gemini ";
                    cout<<"or Cancer.\n";
                    cout<<"Gemini horoscope...\n";
                    cout<<"Cancer horoscope...\n";
                }
                else if (day>21){
                    cout<<"You are a Cancer!\n";
                    cout<<"Cancer horoscope...\n";
                }
                break;
            case 7:
                if (day<22){
                    cout<<"You are a Cancer!\n";
                    cout<<"Cancer horoscope...\n";
                }
                else if (day==22||day==23){
                    cout<<"You are on the cusp, you can be either Cancer or Leo.\n";
                    cout<<"Cancer horoscope...\n";
                    cout<<"Leo horoscope...\n";
                }
                else if (day>23){
                    cout<<"You are a Leo!\n";
                    cout<<"Leo horoscope...\n";
                }
                break;
            case 8:
                if (day<23){
                    cout<<"You are a Leo!\n";
                    cout<<"Leo horoscope...\n";
                }
                else if (day==23||day==24){
                    cout<<"You are on the cusp, you can be either Leo or Virgo.\n";
                    cout<<"Leo horoscope...\n";
                    cout<<"Virgo horoscope...\n";
                }
                else if (day>24){
                    cout<<"You are a Virgo!\n";
                    cout<<"Virgo horoscope...\n";
                }
                break;
            case 9:
                if (day<22){
                    cout<<"You are a Virgo!\n";
                    cout<<"Virgo horoscope...\n";
                }
                else if (day==22||day==23){
                    cout<<"You are on the cusp, you can be either Virgo or Libra.\n";
                    cout<<"Virgo horoscope...\n";
                    cout<<"Libra horoscope...\n";
                }
                else if (day>23){
                    cout<<"You are a Libra!\n";
                    cout<<"Libra horoscope...\n";
                }
                break;
            case 10:
                if (day<22){
                    cout<<"You are a Libra!\n";
                    cout<<"Libra horoscope..\n";
                }
                else if (day==22||day==23){
                    cout<<"You are on the cusp, you can be either Libra or Scorpio.\n";
                    cout<<"Libra horoscope...\n";
                    cout<<"Scorpio horoscope...\n";
                }
                else if (day>23){
                    cout<<"You are a Scorpio!\n";
                    cout<<"Scorpio horoscope..\n";
                }
                break;
            case 11:
                if (day<21){
                    cout<<"You are a Scorpio!\n";
                    cout<<"Scorpio horoscope..\n";
                }
                else if (day==21||day==22){
                    cout<<"You are on the cusp, you can be either Scorpio or ";
                    cout<<"Sagittarus.\n";
                    cout<<"Scorpio horoscope...\n";
                    cout<<"Sagittarus horoscope...\n";
                }
                else if (day>22){
                    cout<<"You are a Sagittarus!\n";
                    cout<<"Sagittarus horoscope..\n";
                }
                break;
            case 12:
                if (day<21){
                    cout<<"You are a Sagittarus!\n";
                    cout<<"Sagittarus horoscope..\n";
                }
                else if (day==21||day==22){
                    cout<<"You are on the cusp, you can be either Sagittarus or ";
                    cout<<"Capricorn.\n";
                    cout<<"Sagittarus horoscope...\n";
                    cout<<"Capricorn horoscope...\n";
                }
                else if (day>22){
                    cout<<"You are a Capricorn!\n";
                    cout<<"Capricorn horoscope..\n";
                }
                break;
        }
     cout<< "Would you like to enter another birthday?";
     cin>> ans;
    } while (ans=='y'||ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}