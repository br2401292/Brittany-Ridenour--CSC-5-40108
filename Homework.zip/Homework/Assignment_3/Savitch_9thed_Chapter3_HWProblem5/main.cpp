/* 
  File:  Chapter 3 HW Problem 5
  Author: Brittany Ridenour
  Created on January 16, 2017, 9:19 PM
  Purpose:  Program finds and outputs all prime number between 3 and 100.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int n, s, k;
    
    //Input values
    n=3;
    s=n-1;
    k=n%s;
    //Process by mapping inputs to outputs
    do{
        do{
        switch (k){
            case 0:
                n++;
                break;
            default:
                s--;
                break;
        }} while (s>1);
        if (s<2){
        cout<<n<<endl;
        n++;
        }
    } while (n<100);

    //Output values

    //Exit stage right!
    return 0;
}