/* 
  File:   Chapter 3
  Author: Brittany Ridenour
  Created on January 16, 2017, 3:00 PM
  Purpose: Score a game of rock-paper-scissors for as many times as the user 
 * would like to play.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char player1, player2, ans;
    int score1, score2;
    
    //Input values
    score1=0;
    score2=0;
    do
    {
    cout<< "Player 1 enter R, P, or S: ";
    cin>> player1;
    cout<< "Player 2 enter R, P, or S: ";
    cin>> player2;
    
    if ((player1== 'r' || player1== 'R') && (player2== 'p' || player2=='P'))
        {
        cout<<"Paper covers rock, Player 2 wins!\n";
        score2++;
        }
    else if ((player1== 'r'|| player1=='R') && (player2== 's'|| player2=='S'))
        {
        cout<< "Rock breaks scissors, Player 1 wins!\n";
        score1++;
        }
    else if ((player1=='p'||player1=='P')&&(player2=='r'||player2=='R'))
        {
        cout<< "Paper covers rock, Player 1 wins!\n";
        score1++;
        }
    else if ((player1=='p'||player1=='P')&&(player2=='s'||player2=='S'))
        {
        cout<< "Scissors cuts paper, Player 2 wins!\n";
        score2++; 
        }
    else if ((player1=='s'||player1=='S')&&(player2=='p'||player2=='P'))
        {
        cout<< "Scissors cuts paper, Player 1 wins!\n";
        score1++;
        }
    else if ((player1=='s'||player1=='S')&&(player2=='r'||player2=='R'))
        {
        cout<< "Rock breaks scissors, Player 2 wins!\n";
        score2++;
        }
    else if (player1==player2)
        {
        cout<< "Tie.";
        }
    cout<< "Player 1 has "<<score1<< " points and player 2 has "<<score2<<" points.\n";
    cout<< "Would you like to play again?";
    cin>> ans;p
            
    
    }
    while (ans=='y'||ans=='Y');
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}