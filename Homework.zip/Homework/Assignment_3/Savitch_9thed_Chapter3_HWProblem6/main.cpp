/* 
  File:   Chapter 3 HW Problem 6
  Author: Brittany Ridenour
  Created on January 16, 2017, 10:22 PM
  Purpose:  User enters the weight and radius of a sphere and program outputs 
 * whether the object will sink or float.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double f, v, w, r;
    const double y=62.4;
    
    //Input values
    v=((4/3)*3.14)*(r*r*r);
    //Process by mapping inputs to outputs
    cout<<"Please enter the radius for the sphere:\n";
    cin>>r;
    cout<<"Please enter the weight of the sphere:\n";
    cin>>w;
    f=v*y;
    if (f>=w){
        cout<<"The sphere will float.\n";
    }
    else {
        cout<<"The sphere will sink.\n";
    }
            
    //Output values

    //Exit stage right!
    return 0;
}