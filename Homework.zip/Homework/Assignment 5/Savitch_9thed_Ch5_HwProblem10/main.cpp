/* 
  File:  Chapter 5 Hw problem 10
  Author: Brittany Ridenour
  Created on February 2, 2017, 10:26 PM
  Purpose:  enter a value in cents and output the number of each type of coins needed
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void coins(int value, int& amt_left);
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int amount;
    //Input values
    cout<<"Please enter the amount of change:\n";
    cin>>amount;
    //Process by mapping inputs to outputs
    if (0<amount<100)
    {
        coins(25,amount);
        coins(10,amount);
        coins(1,amount);
    }
    //Output values

    //Exit stage right!
    return 0;
}
void coins(int value, int& amt_left)
{
    int coin;
    coin=amt_left/value;
    amt_left=amt_left%value;
    if (value==25)
    {cout<<coin<<" quarters ";}
    else if (value==10)
    {cout<<coin<<" dimes ";}
    else if (value==1)
    {cout<<"and "<<coin<<" pennies.";}
    
}