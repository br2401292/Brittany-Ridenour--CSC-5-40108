/* 
  File:   Chapter 5 Hw Problem9
  Author: Brittany Ridenour
  Created on February 2, 2017, 10:11 PM
  Purpose:  Enter 3 sides of a triangle and output the perimeter and area
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void compute(int s1p,int s2p,int s3p);
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int s1,s2,s3;
    char ans;
    //Input values
    do{
    cout<<"Please enter three side lengths of a triangle:\n";
    cin>>s1>>s2>>s3;
    //Process by mapping inputs to outputs
    if ((s1+s2)>s3 && (s1+s3)>s2 && (s2+s3)>s1)
    {
        compute(s1,s2,s3);
    }
    else
    {
        cout<<"Sorry, you cannot construct a triangle with those lengths.";
    }
    cout<<"Would you like to enter another set of lengths?\n";
    cin>>ans;
    }while(ans=='y'||ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}
void compute(int s1p,int s2p,int s3p)
{
    int s,a,p;
    s=(s1p+s2p+s3p)/2;
    a=sqrt(s*(s-s1p)*(s-s2p)*(s-s3p));
    p=s1p+s2p+s3p;
    cout<<"The area of the triangle is "<<a<<" and the perimeter is "<<p<<endl;
}