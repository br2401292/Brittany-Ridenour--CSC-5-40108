/* 
  File:  Chapter 5 Hw Problem5
  Author: Brittany Ridenour
  Created on February 2, 2017, 9:15 PM
  Purpose:  Read weight in lbs and ozs and output kg and grams
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void conversion();
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int lbs,ozs,ans;
    //Input values
    do{
    //Process by mapping inputs to outputs
    conversion();
    //Output values
    cout<<"would you like to enter another weight?\n";
    cin>>ans;
    }while (ans=='y'||ans=='Y');
    //Exit stage right!
    return 0;
}
void conversion()
{
    int oz,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in pounds and ounces:\n";
    cin>>lbs>>ozs;
    oz=ozs+(lbs*16);
    conv=ozs*28.3495;
    kgs=conv/1000;
    gs=conv%1000;
    
    cout<<lbs<<" lbs and "<<ozs<<" ozs is equivalent to "<<kgs<<" kgs and "<<gs<<" grams.\n";
}