/* 
  File:  Chapter 5 Hw Problem 1
  Author: Brittany Ridenour
  Created on February 2, 2017, 4:12 PM
  Purpose:  Function that computes the average and standard deviation of four scores.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double avg_function(double par1,double par2,double par3,double par4);//computes the average of 4 values
double std_dev_function(double par1,double par2,double par3,double par4,double avg_val);//computes the standard deviation of 4 values
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double score1,score2,score3,score4,sc1,sc2,sc3,sc4,avg,std_dev;
    char ans;
    //Input values
    do{
    cout<<"Please enter 4 scores:\n";
    cin>>score1>>score2>>score3>>score4;
    
    avg=avg_function(score1,score2,score3,score4);
    
    std_dev=std_dev_function(score1,score2,score3,score4,avg);
    
    cout<<"The average of "<<score1<<", "<<score2<<", "<<score3<<", and "<<score4;
    cout<<" is "<<avg<<endl;
    cout<<"The standard deviation is "<<std_dev<<endl;
    cout<<"Would you like to enter another set of scores?\n";
    cin>>ans;
    }while(ans=='y'||ans=='Y');
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
double avg_function(double par1,double par2,double par3,double par4)
{
    double ans;
    ans=(par1+par2+par3+par4)/4;
    
    return(ans);
}
double std_dev_function(double par1,double par2,double par3,double par4,double avg_val)
{
    int sc1,sc2,sc3,sc4,t1,t2,t3,t4,avg,ans;
    
    sc1=par1-avg_val;
    sc2=par2-avg_val;
    sc3=par3-avg_val;
    sc4=par4-avg_val;
    
    t1=pow(sc1,2.0);
    t2=pow(sc2,2.0);
    t3=pow(sc3,2.0);
    t4=pow(sc4,2.0);
    
    avg=avg_function(t1,t2,t3,t4);
    ans=sqrt(avg);
    
    return(ans);
}