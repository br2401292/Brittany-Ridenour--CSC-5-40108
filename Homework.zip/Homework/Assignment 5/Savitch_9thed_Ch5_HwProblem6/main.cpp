/* 
  File:  Chapter 5 Hw Problem 6
  Author: Brittany Ridenour
  Created on February 2, 2017, 9:36 PM
  Purpose:  Read weight in kg and grams and outputs lbs and ozs
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void conversion();
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char ans;
    //Input values
    do{
    //Process by mapping inputs to outputs
    conversion();
    //Output values
    cout<<"would you like to enter another weight?\n";
    cin>>ans;
    }while (ans=='y'||ans=='Y');
    //Exit stage right!
    return 0;
}
void conversion()
{
    int t,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in kilograms and grams:\n";
    cin>>kgs>>gs;
    t=gs+(kgs*1000);
    conv=t*.035274;
    lbs=conv/16;
    ozs=conv%16;
    
    cout<<kgs<<" kgs and "<<gs<<" grams is equivalent to "<<lbs<<" lbs and "<<ozs<<" ozs.\n";
}