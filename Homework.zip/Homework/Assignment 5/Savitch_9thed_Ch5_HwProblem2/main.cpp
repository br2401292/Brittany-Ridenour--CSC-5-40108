/* 
  File:  Chapter 5 Hw Problem 2
  Author: Brittany Ridenour
  Created on February 2, 2017, 4:58 PM
  Purpose:  Read a length given in feet and inches and out put in meters and centimeters
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
int conversion(int feet_par,int in_par);//convert ft/in to m/cm
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int feet,in,meter,cm,conv;
    char ans;
    //Input values
    do{
    cout<<"Please enter a lenth in feet and inches:\n";
    cin>>feet>>in;
    
    conv=conversion(feet,in);
    meter=conv/100;
    cm=conv%100;
    
    cout<<feet<<" ft and "<<in<<" in is equivalent to "<<meter<<" m and "<<cm<<" cm.\n";
    cout<<"Would you like to enter another length?\n";
    cin>>ans;
    }while (ans=='y'||ans=='Y');
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
int conversion(int feet_par,int in_par)
{
    int inches; 
    double cm_tot;
    inches=in_par+(feet_par*12);
    cm_tot=inches*2.54;
    return(cm_tot);
}