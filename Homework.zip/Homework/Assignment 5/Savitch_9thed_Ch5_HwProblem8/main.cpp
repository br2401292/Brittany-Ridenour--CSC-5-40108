/* 
  File:   Chapter 5 Hw Problem 8
  Author: Brittany Ridenour
  Created on February 2, 2017, 9:50 PM
  Purpose: Combine all weight/length conversion functions
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void weight_conv();
void length_conv();
void conversion1();
void conversion2();
void conv1();
void conv2();
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int ans1;
    char ans2;
    //Input values
    cout<<"If you would like to perform a length conversion, enter 1\n";
    cout<<"If you would like to perform a weight conversion, enter 2\n";
    cin>>ans1;
    //Process by mapping inputs to outputs
    do{
        if (ans1==1)
        {
            length_conv();
        }
        else if (ans1==2)
        {
            weight_conv();
        }
        cout<<"Would you like to choose another conversion type?\n";
        cin>>ans2;
    }while(ans2=='y'||ans2=='Y');
    //Output values

    //Exit stage right!
    return 0;
}
void length_conv()
{
    int ans1,feet,in,meter,cm,conv;
    char ans2;
    //Input values
    do{
    cout<<"If you would like to convert from feet/inches to meters/centimeters, enter 1\n";
    cout<<"If you would like to convert from meters/centimeters to feet/inches, enter 2\n";
    cin>>ans1;
    if(ans1==1)
    {
        conversion1();
    }
    else if (ans1==2)
    {
        conversion2();
    }
    cout<<"Would you like to try another conversion?\n";
    cin>>ans2;
    }while(ans2=='y'||ans2=='Y');
}
void conversion1()
{
    int t,in,feet,meter,cm,conv;
    cout<<"Please enter a length in feet and inches:\n";
    cin>>feet>>in;
    t=in+(feet*12);
    conv=t*2.54;
    meter=conv/100;
    cm=conv%100;
    
    cout<<feet<<" ft and "<<in<<" in is equivalent to "<<meter<<" m and "<<cm<<" cm.\n";
}
void conversion2()
{
    int meter,cm,conv,t,feet,in;
    cout<<"Please enter a length in meters and centimeters:\n";
    cin>>meter>>cm;
    t=cm+(meter*100);
    conv=t*0.39;
    feet=conv/12;
    in=conv%12;
    
    cout<<meter<<" m and "<<cm<<" cm is equivalent to "<<feet<<" ft and "<<in<<" in.\n";
}
void weight_conv()
{
    int ans1;
    char ans2;
    do{
    cout<<"If you would like to convert pounds/ounces to kilograms/grams, enter 1\n";
    cout<<"If you would like to convert kilograms/grams to pounds/ounces, enter 2\n";
    cin>>ans1;
    
    if (ans1==1)
    {
        conv1();
    }
    else if (ans1==2)
    {
        conv2();
    }
    cout<<"Would you like to perform another conversion?\n";
    cin>>ans2;
    }while(ans2=='y'||ans2=='Y');
}
void conv1()
{
    int t,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in pounds and ounces:\n";
    cin>>lbs>>ozs;
    t=ozs+(lbs*16);
    conv=t*28.3495;
    kgs=conv/1000;
    gs=conv%1000;
    
    cout<<lbs<<" lbs and "<<ozs<<" ozs is equivalent to "<<kgs<<" kgs and "<<gs<<" grams.\n";
}
void conv2()
{
    int t,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in kilograms and grams:\n";
    cin>>kgs>>gs;
    t=gs+(kgs*1000);
    conv=t*.035274;
    lbs=conv/16;
    ozs=conv%16;
    
    cout<<kgs<<" kgs and "<<gs<<" grams is equivalent to "<<lbs<<" lbs and "<<ozs<<" ozs.\n";
}