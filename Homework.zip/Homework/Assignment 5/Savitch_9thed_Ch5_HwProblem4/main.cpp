/* 
  File:   Chapter 5 Hw Problem 4
  Author: Brittany Ridenour
  Created on February 2, 2017, 5:19 PM
  Purpose:  User chooses to convert from ft/in to m/cm or vice-versa, then program
 * performs conversion
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
int conversion1(int feet_par,int in_par);
int conversion2(int m_par,int cm_par);
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int ans1,feet,in,meter,cm,conv;
    char ans2;
    //Input values
    do{
    cout<<"If you would like to convert from feet/inches to meters/centimeters, enter 1\n";
    cout<<"If you would like to convert from meters/centimeters to feet/inches, enter 2\n";
    cin>>ans1;
    if(ans1==1)
    {
        cout<<"Please enter a length in feet and inches:\n";
        cin>>feet>>in;
    
        conv=conversion1(feet,in);
        meter=conv/100;
        cm=conv%100;
    
        cout<<feet<<" ft and "<<in<<" in is equivalent to "<<meter<<" m and "<<cm<<" cm.\n";
    }
    else if (ans1==2)
    {
        cout<<"Please enter a length in meters and centimeters:\n";
        cin>>meter>>cm;
    
        conv=conversion2(meter,cm);
        feet=conv/12;
        in=conv%12;
    
        cout<<meter<<" m and "<<cm<<" cm is equivalent to "<<feet<<" ft and "<<in<<" in.\n";
    }
    else
    {
        cout<<"Sorry, that was not a valid entry.\n";
    }
    cout<<"Would you like to try another conversion?\n";
    cin>>ans2;
    }while(ans2=='y'||ans2=='Y');
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
int conversion1(int feet_par,int in_par)
{
    int inches; 
    double cm_tot;
    inches=in_par+(feet_par*12);
    cm_tot=inches*2.54;
    return(cm_tot);
}
int conversion2(int m_par,int cm_par)
{
    int centimeters; 
    double in_tot;
    centimeters=cm_par+(m_par*100);
    in_tot=centimeters*0.39;
    return(in_tot);
}