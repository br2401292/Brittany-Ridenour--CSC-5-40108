/* 
  File:   Chapter 5 Hw Problem 7
  Author: Brittan Ridenour
  Created on February 2, 2017, 9:40 PM
  Purpose:  User chooses a weight to enter and program performs the conversion
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void conversion1();//converts lbs/oz to kg/g
void conversion2();//converts kg/g to lbs/oz
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int ans1;
    char ans2;
    //Input values
    do{
    cout<<"If you would like to convert pounds/ounces to kilograms/grams, enter 1\n";
    cout<<"If you would like to convert kilograms/grams to pounds/ounces, enter 2\n";
    cin>>ans1;
    //Process by mapping inputs to outputs
    if (ans1==1)
    {
        conversion1();
    }
    else if (ans1==2)
    {
        conversion2();
    }
    cout<<"Would you like to perform another conversion?\n";
    cin>>ans2;
    }while(ans2=='y'||ans2=='Y');
    //Output values

    //Exit stage right!
    return 0;
}
void conversion1()
{
    int t,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in pounds and ounces:\n";
    cin>>lbs>>ozs;
    t=ozs+(lbs*16);
    conv=t*28.3495;
    kgs=conv/1000;
    gs=conv%1000;
    
    cout<<lbs<<" lbs and "<<ozs<<" ozs is equivalent to "<<kgs<<" kgs and "<<gs<<" grams.\n";
}
void conversion2()
{
    int t,lbs,ozs,kgs,gs,conv;
    cout<<"Please enter a weight in kilograms and grams:\n";
    cin>>kgs>>gs;
    t=gs+(kgs*1000);
    conv=t*.035274;
    lbs=conv/16;
    ozs=conv%16;
    
    cout<<kgs<<" kgs and "<<gs<<" grams is equivalent to "<<lbs<<" lbs and "<<ozs<<" ozs.\n";
}