/* 
  File:  Chapter 5 Hw Problem 2
  Author: Brittany Ridenour
  Created on February 2, 2017, 5:11 PM
  Purpose:  Read a length given in meters and cm and out put in ft and in
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
int conversion(int m_par,int cm_par);//convert m/cm to ft/in
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int feet,in,meter,cm,conv;
    char ans;
    //Input values
    do{
    cout<<"Please enter a length in meters and centimeters:\n";
    cin>>meter>>cm;
    
    conv=conversion(meter,cm);
    feet=conv/12;
    in=conv%12;
    
    cout<<meter<<" m and "<<cm<<" cm is equivalent to "<<feet<<" ft and "<<in<<" in.\n";
    cout<<"Would you like to enter another length?\n";
    cin>>ans;
    }while (ans=='y'||ans=='Y');
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
int conversion(int m_par,int cm_par)
{
    int centimeters; 
    double in_tot;
    centimeters=cm_par+(m_par*100);
    in_tot=centimeters*0.39;
    return(in_tot);
}