/* 
  File: Chapter 2 HW Problem 5
  Author: Brittany Ridenour
  Created on January 12, 2017, 11:17 PM
  Purpose:  Write a program that uses the Babylonian algorithm to guess the square
 * root of a number n and iterates 100 times.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double n, guess, r;
    int count;
    
    //Input values
    count=0;
    cout<<"Please enter the number you would like to find the square root of: ";
    cin>> n;
    cout<<"Please enter your initial guess: ";
    cin>> guess;
    //Process by mapping inputs to outputs
    while (count<100)
    {
        r=n/guess;
        guess=(guess+r)/2;
        count=count+1;
    }
    //Output values
    cout<<"After 100 iterations of the Babylonian algorithm,\n";
    cout<<"the approximate square root of "<<n<<" is "<<guess<<endl;
    

    //Exit stage right!
    return 0;
}