/* 
  File: Chapter 2 Hw Problem 4
  Author: Brittany Ridenour
  Created on January 12, 2017, 11:04 PM
  Purpose: Convert the weight of a cereal box in oz to metric tons and also
 * give the number of boxes required to make a matric ton.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double box_oz, box_ton, box_total;
    const double met_ton_conv=35273.92;
    char ans;
    
    //Input values
    
    //Process by mapping inputs to outputs
    do
    {
        cout<< "Please enter the weight of a cereal boz in ounces: ";
        cin>> box_oz;
        box_ton=box_oz/met_ton_conv;
        cout<< "The cereal box weighs "<<box_oz<<" oz. or "<<box_ton<< " metric tons.\n";
        box_total=met_ton_conv/box_oz;
        cout<< "To make one metric ton, you would need "<<box_total<<" boxes of cereal.\n";
        cout<<"Would you like to enter a new weight? Press y for yes or n for no.\n";
        cin>>ans;
    } while (ans=='y'||ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}