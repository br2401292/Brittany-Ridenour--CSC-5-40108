/* 
  File: Chapter 2 HW Problem 2
  Author: Brittany Ridenour
  Created on January 12, 2017, 9:12 PM
  Purpose:  Enter an annual salary and program will output 6 months worth of
 * retroactive pay, new annual salary, and new monthly salary based on 7.6% increase
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double old_sal,sal_inc, retro_due, ann_sal, month_sal;
    const double pay_inc=0.076;
    char ans;
    
    //Input values
    
    //Process by mapping inputs to outputs
    do
    {
        cout<< "Please enter your current annual salary: $";
        cin>> old_sal;
        sal_inc=(old_sal/12)*pay_inc;
        month_sal=(old_sal/12)+sal_inc;
        retro_due=sal_inc*6;
        ann_sal=month_sal*12;
        cout<< "Based on your annual salary of $"<<old_sal<<" and the 7.6% ";
        cout<< "pay increase retroactive six months,\n";
        cout<< "you will receive $"<<retro_due<<" in retroactive pay.\n";
        cout<< "Your new monthly salary will be $"<<month_sal;
        cout<< " and your annual salary will be $"<<ann_sal<<".\n";
        cout<< "Would you like to enter a new salary? Press y for yes or n for no.\n";
        cin>> ans;
        
    } while (ans=='y'||ans=='Y');
    
    //Output values

    //Exit stage right!
    return 0;
}