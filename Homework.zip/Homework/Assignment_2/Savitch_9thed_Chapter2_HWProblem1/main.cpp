/* 
  File:  Chapter 2 Hw Problem 1
  Author: Brittany Ridenour
  Created on January 12, 2017, 8:38 PM
  Purpose:  Find the max amount of soda a dieter can drink based on their
 * goal weight and the amount of artificial sweetener in each can of soda.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double goal_weight, gw_grams, lethal_dose, max_cans, sweet_per_soda;
    const double sweet_percent=0.001;
    char ans;
    
    //Input values
    sweet_per_soda=350*sweet_percent;
    
    //Process by mapping inputs to outputs
    do
    {
        cout<< "Please enter your goal weight in pounds: ";
        cin>> goal_weight;
        gw_grams=goal_weight*454;
        lethal_dose=gw_grams/7;
        max_cans=lethal_dose/sweet_per_soda;
        cout<< "Based on your goal weight of "<<goal_weight<<" lbs,\n";
        cout<< "It is recommended that you do not consume more than ";
        cout<< lethal_dose <<" grams of artificial sweetener.\n";
        cout<<"This is equivalent to about " << max_cans << " cans of diet soda.\n";
        cout<< "Would you like to enter another goal weight? Press y for yes or n for no:";
        cin>> ans;       
    } while (ans=='y'|| ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}