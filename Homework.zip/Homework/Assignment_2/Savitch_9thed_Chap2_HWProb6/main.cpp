/* 
  File: Chapter 2 HW Problem 6
  Author: Brittany Ridenour
  Created on January 12, 2017, 11:36 PM
  Purpose:  Convert treadmill speed in MPH to minutes and seconds per mile
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int mph, mpmin, minpmile, pace;
    double sec;
    //Input values
    cout<< "Please enter the speed of the treadmill in MPH: ";
    cin>> mph;

    //Process by mapping inputs to outputs
    mpmin=mph/60;
    minpmile=1/mpmin;
    sec=(mph%60)*60;
    cout<< "Your pace is "<<minpmile<<" minutes and "<<sec<<" seconds per mile.\n";
    //Output values

    //Exit stage right!
    return 0;
}