/* 
  File:  Chapter 1 Hw Problem 4
  Author: Brittany Ridenour
  Created on January 10, 2017, 12:13 PM
  Purpose:  User enters a time in seconds and program outputs the distance an
 * object would travel in freefall for the given time.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int t, T, d, D, a;
    
    //Input values
    a=32; //32 ft/s is gravitational acceleration
            
    //Process by mapping inputs to outputs
    cout<< "Give a time (in seconds) that an object is in freefall.\n";
    cin>> t;
    T=t*t;
    d=a*T;
    D=d/2;
    
    //Output values
    cout<< "The object will travel a distance of ";
    cout<< D;
    cout<< " feet in ";
    cout<< t;
    cout<< " seconds.\n";

    //Exit stage right!
    return 0;
}