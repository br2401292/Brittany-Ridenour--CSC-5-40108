/* 
  File:   Chapter 4 HW Problem 4
  Author: Brittany Ridenour
  Created on January 19, 2017, 11:36 PM
  Purpose:  calculate rate of inflation given a current price and price from
 * 1 year ago. Also estimate the new price in 1 and 2 years.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double infl(double curr_par, double old_par); //calcuate inflation using current
//price and price from one year ago
double est_inf(double rate_par, double pr_par); //estimate inflation price in 1 yr

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double curr, old, est1yrinf, inflation, inf1yr, inf2yr;
    char ans;
    //Input values
    do{
    cout<<"Please enter the current price of the object and the old price of the object:\n";
    cin>>curr>>old;
    
    inflation=infl(curr, old); //inflation rate given current & old prices
    inf1yr=est_inf(inflation, curr); //estimated inflation price in 1 yr
    est1yrinf= infl(inf1yr, curr); //estimated inflation rate over next year
    inf2yr= est_inf(est1yrinf, inf1yr); //estimated inflation price in 2 yrs
    
    
    //Process by mapping inputs to outputs
    cout<<"The price inflation of your object is "<<inflation<<"%\n";
    cout<<"In 1 year the price is estimated to rise to $"<<inf1yr<<endl;
    cout<<"and $"<<inf2yr<<" in 2 years.\n";
    cout<<"Would you like to enter another set of prices?\n";
    cin>>ans;
    } while (ans=='y'||ans=='Y');
    
    //Output values

    //Exit stage right!
    return 0;
}
double infl(double curr_par, double old_par)
{
    double inf;
    inf=(curr_par-old_par)/old_par;
    return (inf);
}
double est_inf(double rate_par, double pr_par)
{
    double inc;
    inc=rate_par*pr_par;
    return(pr_par+inc);  
}