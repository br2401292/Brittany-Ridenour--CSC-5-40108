/* 
  File:  Chapter 4 Hw Problem 1
  Author: Brittany Ridenour
  Created on January 19, 2017, 10:15 PM
  Purpose:  Convert liters to gallons and output a cars gas mileage given 
 * the amount of gas used and miles traveled.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another



//Function Prototypes
double mpl_to_mpg(double mi_par, double li_par); //Computes the mpg given gas in Li

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double li, mi, mpg;
    
    //Input values
    
    //Process by mapping inputs to outputs
    cout<<"Please enter the miles traveled and gas used in liters:\n";
    cin>>mi>>li;
    
    mpg = mpl_to_mpg(mi, li);
    
    //Output values
    cout<<"The gas mileage of your car is "<<mpg<<" miles per gallon.\n";

    //Exit stage right!
    return 0;
}
double mpl_to_mpg(double mi_par, double li_par)
{
    const double gal=li_par/0.264179;
    double mipergal;
    mipergal=mi_par/gal;
    return (mipergal);
}
