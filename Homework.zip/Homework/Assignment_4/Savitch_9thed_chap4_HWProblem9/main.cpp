/* 
  File:   Chapter 4 HW Problem 9
  Author: Brittany Ridenour
  Created on January 20, 2017, 11:18 AM
  Purpose:  User enters height, weight, and age and program outputs hat size,
 * jacket size, and waist size.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double jack_size(double height_par, double weight_par, int age_par);
double hat_size(double height_par, double weight_par, int age_par);
double waist_size(double height_par, double weight_par, int age_par);
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double height, weight, jacket, hat, waist;
    int age;
    char ans;
    
    //Input values
    
    //Process by mapping inputs to outputs
    do
    {
      cout<<"Please enter your height in inches, weight, and age:\n";
      cin>>height>>weight>>age;
      
      jacket=jack_size(height, weight, age);
      hat=hat_size(height, weight, age);
      waist=waist_size(height, weight, age);
      
      cout<<"Your jacket size is "<<jacket<<", your hat size is "<<hat<<" and your ";
      cout<<"waist size is "<<waist<<endl;
      
      cout<<"Would you like to enter information for another person?\n";
      cin>>ans;
    } while (ans=='y'||ans=='Y');
    //Output values

    //Exit stage right!
    return 0;
}
double jack_size(double height_par, double weight_par, int age_par)
{
    
    int age_adj;
    double jack;
    if (age_par>30)
    {
    age_adj=((age_par-30)/10)*0.125;
    jack=((height_par*weight_par)/288)+age_adj;
    }
    else {
       jack=(height_par*weight_par)/288;
    }
    return (jack);
}
double hat_size(double height_par, double weight_par, int age_par)
{
    double hat;
    hat=(weight_par/height_par)*2.9;
    return (hat);
}
double waist_size(double height_par, double weight_par, int age_par)
{
    int age_adj;
    double waist;
    if (age_par>28)
    {
    age_adj=((age_par-28)/2)*0.1;
    waist=(weight_par/5.7)+age_adj;
   
    }
    else
    {
        waist=weight_par/5.7;
    }
    return (waist);
}