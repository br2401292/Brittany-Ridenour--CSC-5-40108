/* 
  File:   Chapter 4 HW Problem 8
  Author: Brittany Ridenour
  Created on January 20, 2017, 10:54 AM
  Purpose:  Program that computes annual after-tax cost of a new house for first year.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double mortgage(double price_par, double downpay_par); //calculate annual mortgage
double taxsavings(double price_par, double downpay_par); //calc tax savings
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double price, downpay, cost, ann_mort, tax_sav;
    char ans;
    //Input values
    
    //Process by mapping inputs to outputs
    do
    {
        cout<<"Please enter the price of the house and the down payment made:\n";
        cin>>price>>downpay;
        ann_mort=mortgage(price, downpay);
        tax_sav=taxsavings(price, downpay);
        
        cost=ann_mort-tax_sav;
    //Output values
        cout<<"The after-tax cost of the house after the first year is $"<<cost<<endl;
        cout<<"Would you like to enter information for another house?\n";
        cin>>ans;
    } while (ans=='y'||ans=='Y');
    //Exit stage right!
    return 0;
}
double mortgage(double price_par, double downpay_par)
{
    double loan, intpayed, loanpayed;
    loan=price_par-downpay_par;
    intpayed=.06*loan;
    loanpayed=.03*loan;
    return (intpayed+loanpayed);
}
double taxsavings(double price_par, double downpay_par)
{
    double loan, savings;
    loan=price_par-downpay_par;
    savings=.35*(.06*loan);
    return (savings);
}