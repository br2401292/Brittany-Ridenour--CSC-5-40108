/* 
  File:   Chapter 4 HW Problem 7
  Author: Brittany Ridenour
  Created on January 20, 2017, 10:36 AM
  Purpose:  Write a program to calculate gravitational force between two objects
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
const double G=6.673E-8;

//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double grav_force(double mass1_par, double mass2_par, double dist_par);
//function to calculate gravitational force

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double mass1, mass2, dist, force;
    char ans;
    
    //Input values
    do
    {
    cout<<"Please enter the masses of two objects and the distance between them in ";
    cout<<"scientific notation:\n";
    cin>>mass1>>mass2>>dist;
    
    force= grav_force(mass1, mass2, dist);
    
    //Process by mapping inputs to outputs
    cout<<"The gravitational force between the objects is "<<force;
    cout<<" gram-centimeters per squared second.\n";
    cout<<"Would you like to enter another set of data?";
    cin>>ans;
    } while (ans=='y'||ans=='Y');
    
    //Output values

    //Exit stage right!
    return 0;
}
double grav_force(double mass1_par, double mass2_par, double dist_par)
{
    double gforce, hold;
    hold=pow(dist_par,2.0);
    gforce=(G*mass1_par*mass2_par)/hold;
    return(gforce);
}