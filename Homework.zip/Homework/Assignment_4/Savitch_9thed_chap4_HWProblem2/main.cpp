/* 
  File:  Chapter 4 Hw Problem 1
  Author: Brittany Ridenour
  Created on January 19, 2017, 10:43 PM
  Purpose:  Convert liters to gallons and output the gas mileage for two cars given 
 * the amount of gas used and miles traveled.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another



//Function Prototypes
double mpl_to_mpg(double mi_par, double li_par); //Computes the mpg given gas in Li

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double li1, li2, mi1, mi2, mpg1, mpg2;
    
    //Input values
    
    //Process by mapping inputs to outputs
    cout<<"Please enter the miles traveled and gas used in "
           <<"liters first for car 1 then car 2:\n";
    cin>>mi1>>li1>>mi2>>li2;
    
    mpg1 = mpl_to_mpg(mi1, li1);
    mpg2= mpl_to_mpg(mi2, li2);
    
    //Output values
    cout<<"The gas mileage for car 1 is "<<mpg1<<" miles per gallon.\n";
    cout<<"Car 2's gas mileage is "<<mpg2<<" miles per gallon.\n";

    //Exit stage right!
    return 0;
}
double mpl_to_mpg(double mi_par, double li_par)
{
    const double gal=li_par/0.264179;
    double mipergal;
    mipergal=mi_par/gal;
    return (mipergal);
}
