/* 
  File:   Chapter 4 HW Problem 4
  Author: Brittany Ridenour
  Created on January 19, 2017, 11:15 PM
  Purpose:  calculate rate of inflation given a current price and price from
 * 1 year ago.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double infl(double curr_par, double old_par); //calcuate inflation using current
//price and price from one year ago

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double curr_pr, old_pr, inflation;
    char ans;
    //Input values
    do{
    cout<<"Please enter the current price of the object and the old price of the object:\n";
    cin>>curr_pr>>old_pr;
    
    inflation=infl(curr_pr, old_pr);
    
    //Process by mapping inputs to outputs
    cout<<"The price inflation of your object is "<<inflation<<"%\n";
    cout<<"Would you like to enter another set of prices?\n";
    cin>>ans;
    } while (ans=='y'||ans=='Y');
    
    //Output values

    //Exit stage right!
    return 0;
}
double infl(double curr_par, double old_par)
{
    double inf;
    inf=(curr_par-old_par)/old_par;
    return (inf);
}