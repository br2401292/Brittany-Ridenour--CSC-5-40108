/* 
  File:   Chapter 4 HW Problem 6
  Author: Brittany Ridenour
  Created on January 19, 2017, 12:03 PM
  Purpose:  Calculate interest due on a credit account.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
double int_due(double bal_par, double rate_par, int month_par);//interest due given
//initial balance, monthly rate, and number of months int is paid.
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int month;
    double in_bal, rate_per, rate, months, tot_int;
    char ans;
    
    //Input values
    rate=rate_per/100;
    
    //Process by mapping inputs to outputs
    do {
    cout<<"Please enter your initial balance, the monthly rate percentage, and how many ";
    cout<<"months interest must be paid:\n";
    cin>>in_bal>>rate_per>>months;
    
    tot_int= int_due(in_bal, rate, months);
    
    //Output values
    cout<<"The total interest due on this account is $"<<tot_int<<endl;
    cout<<"Would you like to enter information for another account?\n";
    cin>>ans;
    } while (ans=='y'||ans=='Y');

    //Exit stage right!
    return 0;
}
double int_due(double bal_par, double rate_par, int month_par)
{
    double int_due, hold1, hold2, hold3;
    hold3=pow(month_par,2.0);
    hold2=1+(rate_par/month_par);
    hold3=pow(hold2,hold3);
    int_due=(bal_par*hold3)-bal_par;
    return(int_due);
}