/* 
  File:   Deal or No Deal -Bank Offer
  Author: Brittany Ridenour
  Created on January 3, 2017, 12:15 PM
  Purpose:  Template to be used in all programming
            projects!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void sum_of_cases(int array_par, int size_par);//function that sums all remaining values in case array
void deal_function(int& bank_offer_par, int& my_case_par, int par[], int size_par);
int probability_function(int avg_par);//find how many cases left are over the avg value
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int cases[25]={1,5,10,15,25,50,75,100,200,300,500,750,1000,3000,5000,10000,15000,25000,50000,75000,100000,300000,500000,750000,1000000};
    //The cases array contains all possible prize sizes in dollars from $1 to $1 million
    int offer, sum, tot_left_par, probability, avg_val;//sum_cases: sum of the cases array
    //tot_left is cases left unopened (parameter) //prob_par is chances that the case is at/above avg dollar (parameter)
    char ans; //answer to deal or no deal
    int i, my_case;
    
    sum=sum_of_cases(cases[], 25)+ my_case;
    avg_val=sum/(tot_left_par+1);
    probability=probability_function(avg_val);
    offer=avg_val*(probability/tot_left_par)//sum of cases/(how many left on table + chosen case)=avg value
    //prob_par/total left=chances that the case is at/above avg value
    
    cout<<"Host: That was the banker, he wants to make an offer for the case you chose.\n";
    cout<<endl;
    cout<<"Here is the banker's offer: $"<<offer<<endl;
    cout<<endl;
    cout<<"These are the amounts left that could be in your case or the unopened cases on the table:\n";
    //*** mini program to output all values in case array in ascending order
    for(i=0;i<=25;i++)
    {
        if(cases[i]==0)
        {
            cout<<"xxx\n";
        }
        else
        {
            cout<<"$"<<cases[i]<<endl;
        }
    };
    
    cout<<endl;
    cout<<"Host: Now that you've weighed your options...\n";
    cout<<"             Deal or No Deal?\n";
    cout<<              "(y)     (n)\n";
    cin>>ans;
    cout<<endl;
    if(ans=='y'||ans=='Y')
    {
      deal_function(offer, my_case, cases[], 25);  
    }
    else
    {
       cout<<"Host: You like to take risks... I like it.\n";
       cout<<"      Okay, lets open up some more cases.\n";
    }
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}

void sum_of_cases(int array[], int size_par)
{
    int t, n, sum;
    for(n=0;n<size_par;n++)
    {
        t=array[n];
        sum=sum+t;
    };
    return(sum);
}

void deal_function(int& bank_offer_par, int& my_case_par, int cases[], int size_par)
{
    int n;
    
    cout<<"Host: Okay, so you took the deal.\n";
    cout<<"      Before we open the case you sold, lets find out what is left on the table.\n";
    cout<<endl;
    for(n=0;n<size_par;n++)
    {
      if (cases[n]!=0)
      {
          cout<<"$"<<cases[n]<<endl;
      }
    };
    cout<<endl;
    cout<<"Host: Now to lets open your case\n";
    cout<<endl;
    cout<<"Your case: $"<<my_case_par<<endl;
    cout<<endl;
    if (my_case_par<bank_offer_par)
    {
        cout<<"             Congratulations!\n";
            <<"You sold your case for more than what it was worth\n";
            <<"           You win $"<<bank_offer_par<<"!"<<endl;
    }
    else
    {
        cout<<"Sorry, the banker won this round.\n";
    }
}