/* 
  File:   Project 1 - Deal or No Deal
  Author: Brittany Ridenour
  Created on January 30, 2017, 12:15 PM
  Purpose:  Player starts with 25 cases containing amounts from $1-$1 million.
 * Player will select one case to be their own, then will proceed to open the
 * remaining cases. Every few cases, the banker will make an off to the player 
 * to buy their case. Players can choose to make a deal with the banker or keep 
 * their case until the end. 
 */

//System Libraries
#include <iostream>

using namespace std;

//User Libraries
#include <cstdlib>
#include <ctime>

//Function Prototypes
void open_case_function(int pick_par, int& tot_left_par, int display[][5], int cases[]);
int sum_of_cases(int cases[], int size_par);
int probability_function(int cases[], int size_par, int& avg_par, int tot_left);

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Basic Variables
    srand(time(0));
    int i,j,n,x,y,I,J,luck,t,s,p;
    int my_case;
    //Arrays
    int display[5][5];
            display[0][0]=1;
            display[0][1]=1;
            display[0][2]=1;
            display[0][3]=1;
            display[0][4]=1;
            display[1][0]=1;
            display[1][1]=1;
            display[1][2]=1;
            display[1][3]=1;
            display[1][4]=1;
            display[2][0]=1;
            display[2][1]=1;
            display[2][2]=1;
            display[2][3]=1;
            display[2][4]=1;
            display[3][0]=1;
            display[3][1]=1;
            display[3][2]=1;
            display[3][3]=1;
            display[3][4]=1;
            display[4][0]=1;
            display[4][1]=1;
            display[4][2]=1;
            display[4][3]=1;
            display[4][4]=1;
    int cases[25]={1,5,10,15,25,50,75,100,200,300,500,750,1000,3000,5000,10000,15000,25000,50000,75000,100000,300000,500000,750000,1000000};
    int tot_left=25;
    int pick, random;
    int offer, sum, probability, avg_val;
    char ans;
    
    
    //Opening of game
    cout<<"Welcome to Deal or No Deal!\n";
    cout<<endl;
    cout<<"Host: There are 25 cases on the table you see here\n";
    cout<<endl;
        
      for (i=0;i<=5;i++)
      { for(j=0;j<=5;j++)
        {   if (i==0)
            {   if (j==0)
                {cout<<"  ";}
                else 
                {cout<<j<<" ";}
            }
            else
            {
                if (j==0)
                {cout<<i<<" ";}
                else
                {   if(display[i-1][j-1]==1)
                    {cout<<"$ ";}
                    else
                    {cout<<"  ";}   }
            }
        }; cout<<endl;
      };
      
      
    cout<<endl;
    cout<<"Host: And each one contains one of these prizes to take home:\n";
        for(n=0;n<25;n++)
        {
          if(cases[n]==0)
            {cout<<"xxx\n";}
          else
            {cout<<"$"<<cases[n]<<endl;}
        };
    cout<<"Host: Now you're going to choose a case from the table to be yours.\n";
    cout<<"      You can do this by entering the row number and the column\n";
    cout<<"      number (separated by a space) of the case you want.\n";
    cout<<endl;
    cout<<"Please choose your case: \n";
    cin>>x>>y;
    display[x-1][y-1]=0;
    cout<<endl;
    luck=rand()%25;
    my_case=cases[luck];
    cases[luck]=0;
    tot_left--;
    pick=4;
    
    do{
    cout<<"Host: Great. Your case has been removed from the table.\n";
    cout<<endl;
    
    for (i=0;i<=5;i++)
      { for(j=0;j<=5;j++)
        {   if (i==0)
            {   if (j==0)
                {cout<<"  ";}
                else 
                {cout<<j<<" ";}
            }
            else
            {
                if (j==0)
                {cout<<i<<" ";}
                else
                {   if(display[i-1][j-1]==1)
                    {cout<<"$ ";}
                    else
                    {cout<<"  ";}   }
            }
        }; cout<<endl;
      };
      
    if (tot_left<20)
    {pick=3;}
    do{
        cout<<"Host: Now to open "<<pick<<" more cases.\n";
        cout<<endl;
        cout<<"Please choose a case to open: ";
        cin>>x>>y;
        if(x==0 || y==0 || x>5 || y>5)
            {
               cout<<"Sorry, that is not a valid entry.\n";
               cout<<"Please choose a case to open: ";
               cin>>x>>y;
               I=x-1;
               J=y-1;
               display[I][J]=0;
            }
        else if (display[x][y]==0)
            {
                cout<<"Sorry, that case has already been opened.\n";
                cout<<"Please choose a case to open: ";
                cin>>x>>y;
                I=x-1;
                J=y-1;
                display[I][J]=0;
            }
        else
            {
                I=x-1;
                J=y-1;
                display[I][J]=0;
            }
        cout<<endl;
        
        do{
           random=(rand()%25);
           if (cases[random]!=0)
           {
               cout<<"This case held $"<<cases[random]<<endl;
               cases[random]=0;
           }
        }while (cases[random]==0);
        
        tot_left--;
        pick--;
        
        if (pick==0)
        {cout<<"Looks like the banker is calling...\n";}
        else
        { 
            cout<<"Here are the cases left\n";
            
            for (i=0;i<=5;i++)
            {
                for(j=0;j<=5;j++)
                {
                    if (i==0)
                    {
                        if (j==0)
                        {cout<<"  ";}
                        else 
                        {cout<<j<<" ";}
                    }
                    else
                    {
                        if (j==0)
                        {cout<<i<<" ";}
                        else
                        {
                            if(display[i-1][j-1]==1)
                            {cout<<"$ ";}
                            else
                            {cout<<"X ";}
                        }
                    }
        };
        cout<<endl;
        };
        }
        } while (pick!=0);
        
        for(n=0;n<25;n++)
            {
            t=cases[n];
            s=s+t;
            };
        for(n=0;n<25;n++)
            {
            if (cases[n]>=avg_val)
            {p++;}};
        
        sum=s + my_case;
        avg_val=sum/(tot_left+1);
        probability=p/tot_left;
        offer=avg_val*(probability/tot_left);
    cout<<"Host: That was the banker, he wants to make an offer for the case you chose.\n";
    cout<<endl;
    cout<<"Here is the banker's offer: $"<<offer<<endl;
    cout<<endl;
    cout<<"These are the amounts left that could be in your case or the unopened cases on the table:\n";
    
    for(i=0;i<=25;i++)
    {
        if(cases[i]==0)
        {
            cout<<"xxx\n";
        }
        else
        {
            cout<<"$"<<cases[i]<<endl;
        }
    };
    
    cout<<endl;
    cout<<"Host: Now that you've weighed your options...\n";
    cout<<"             Deal or No Deal?\n";
    cout<<              "(y)     (n)\n";
    cin>>ans;
    cout<<endl;
    if(ans=='y'||ans=='Y')
    {
            cout<<"Host: Okay, so you took the deal.\n";
            cout<<"      Before we open the case you sold, lets find out what is left on the table.\n";
            cout<<endl;
            for(n=0;n<25;n++)
            {
                if (cases[n]!=0)
                {
                cout<<"$"<<cases[n]<<endl;
                }
            };
            cout<<endl;
            cout<<"Host: Now to lets open your case\n";
            cout<<endl;
            cout<<"Your case: $"<<my_case<<endl;
            cout<<endl;
            if (my_case<offer)
            {
                cout<<"             Congratulations!\n";
                cout<<"You sold your case for more than what it was worth\n";
                cout<<"           You win $"<<offer<<"!"<<endl;
            }
            else
                {cout<<"Sorry, the banker won this round.\n";}  
    }
    else
    {
       cout<<"Host: You like to take risks... I like it.\n";
       cout<<"      Okay, lets open up some more cases.\n";
    }
    }while(tot_left>3 || ans!='y' ||ans!='Y');
    
    if (tot_left<=3)
    {
        cout<<"      Before we open the case you sold, lets find out what is left on the table.\n";
        cout<<endl;
        for(n=0;n<25;n++)
        {
            if (cases[n]!=0)
        {
          cout<<"$"<<cases[n]<<endl;
        }};
        cout<<endl;
        cout<<"Host: Now lets open your case\n";
        cout<<endl;
        cout<<"Your case: $"<<my_case<<endl;
        cout<<endl;
    }
    
    cout<<"Thanks for Playing!\n";
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}

int probability_function(int cases[], int size_par, int& avg_par, int tot_left)
{
    int t=0, n,p;
    for(n=0;n<size_par;n++)
    {
        if (cases[n]>=avg_par)
        {t++;}
        
    };
    p=t/tot_left;
    return(p);
}

int sum_of_cases(int cases[], int size_par)
{
    int t, n, sum;
    for(n=0;n<size_par;n++)
    {
        t=cases[n];
        sum=sum+t;
    };
    return(sum);
}

void deal_function(int& bank_offer_par, int& my_case_par, int cases[], int size_par)
{
    int n;
    cout<<"Host: Okay, so you took the deal.\n";
    cout<<"      Before we open the case you sold, lets find out what is left on the table.\n";
    cout<<endl;
    for(n=0;n<size_par;n++)
    {
      if (cases[n]!=0)
      {
          cout<<"$"<<cases[n]<<endl;
      }
    };
    cout<<endl;
    cout<<"Host: Now to lets open your case\n";
    cout<<endl;
    cout<<"Your case: $"<<my_case_par<<endl;
    cout<<endl;
    if (my_case_par<bank_offer_par)
    {
        cout<<"             Congratulations!\n";
        cout<<"You sold your case for more than what it was worth\n";
        cout<<"           You win $"<<bank_offer_par<<"!"<<endl;
    }
    else
    {
        cout<<"Sorry, the banker won this round.\n";
    }
}

