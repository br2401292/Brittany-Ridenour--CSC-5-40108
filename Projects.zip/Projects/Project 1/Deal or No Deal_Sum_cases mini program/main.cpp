/* 
  File:   Deal or No Deal - Sum cases/display values/ determine win/lose ending
  Author: Brittany Ridenour
  Created on January 3, 2017, 12:15 PM
  Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int cases[25]={1,5,10,15,25,50,75,100,200,300,500,750,1000,3000,5000,10000,15000,25000,50000,75000,100000,300000,500000,750000,1000000};
    
    int x, i, sum_par;//parameter is where the cases array will be plugged in
    sum_par=0;
    //Input values
    //summing all values in remaining cases
    for(i=0;i<=24;i++)
    {
        x=cases[i];
        sum_par=sum_par+x;
    };
    
    //displaying values available
    for(i=0;i<25;i++)
    {
        if(cases[i]==0)
        {
            cout<<"xxx\n";
        }
        else
        {
            cout<<"$"<<cases[i]<<endl;
        }
    };
    
    //game ending-player made a deal
    
    int my_case_par;//case/value inside the players chosen case
    int bank_offer_par;//deal accepted by the bank
    int n;
    
    cout<<"Host: Okay, so you took the deal.\n";
    cout<<"      Before we open the case you sold, lets find out what is left on the table.\n";
    cout<<endl;
    for(n=0;n<=24;n++)
    {
      if (cases[n]!=0)
      {
          cout<<"$"<<cases[n]<<endl;
      }
    };
    cout<<endl;
    cout<<"Host: Now to lets open your case\n";
    cout<<endl;
    cout<<"Your case: $"<<my_case_par<<endl;
    cout<<endl;
    if (my_case_par<bank_offer_par)
    {
        cout<<"             Congratulations!\n";
            <<"You sold your case for more than what it was worth\n";
            <<"           You win $"<<bank_offer_par<<"!"<<endl;
    }
    else
    {
        cout<<"Sorry, the banker won this round.\n";
    }
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}