/* 
  File:  Deal or No Deal - Open case/choose case function testing
  Author: Brittany Ridenour
  Created on January 3, 2017, 12:15 PM
  Purpose: given the display table, players enter coordinates for a 'case' and the 
 * //program 1. outputs the value of the case 2. changes the value of display array
 * /for those coordinates 3. determines if player opens another case or bank makes an offer.
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototype

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables

    int display[5][5];
    display[0][0]=1;//The display table has 25 "cases" for the player to choose from
    display[0][1]=1;// by entering the "coordinates". Using the multidimensional array allows for player to enter 
    display[0][2]=1;//the row # hat corresponds to one of the first 5 addresses, then the column number that specifies
    display[0][3]=1;//one of the addresses within that.
    display[0][4]=1;//each "coordinate" starts at value 1, meaning the case has not been chosen/opened.
    display[1][0]=1;
    display[1][1]=1;
    display[1][2]=1;
    display[1][3]=1;
    display[1][4]=1;
    display[2][0]=1;
    display[2][1]=1;//display values must all start as a 1 and be able to change in any random order.
    display[2][2]=1;// because we have not gotten to arrays yet, I am unable to assign values to each address
    display[2][3]=1;// in an efficient manner that also allows the changes I will need to make later.
    display[2][4]=1;
    display[3][0]=1;
    display[3][1]=1;
    display[3][2]=1;
    display[3][3]=1;
    display[3][4]=1;
    display[4][0]=1;
    display[4][1]=1;
    display[4][2]=1;
    display[4][3]=1;
    display[4][4]=1;
    
    int cases[25]={1,5,10,15,25,50,75,100,200,300,500,750,1000,3000,5000,10000,15000,25000,50000,75000,100000,300000,500000,750000,1000000};
    //The cases array contains all possible prize sizes in dollars from $1 to $1 million

    int x, y, i, j; //coordinate variables for display table/choosing case.
    int random;//when a case is chosen it is randomly assigned a remaining prize value
    srand(time(0));
    int tot_left, tot_left_par, pick_par; //number of cases left on the table
    //number of cases left after last bank offer(parameter) //number of cases to pick (parameter)
    int I,J; //conversion on xy coordinate to appropriate array index

    do{
        cout<<"Host: Now to open "<<pick_par<<" more cases.\n";
        cout<<endl;
        cout<<"Please choose a case to open: ";
        cin>>x>>y;
        if(x==0 || y==0 || x>5 || y>5)
            {
               cout<<"Sorry, that is not a valid entry.\n";
               cout<<"Please choose a case to open: ";
               cin>>x>>y;
               I=x-1;
               J=y-1;
               display[I][J]=0;
            }
        else if (display[x][y]==0)
            {
                cout<<"Sorry, that case has already been opened.\n";
                cout<<"Please choose a case to open: ";
                cin>>x>>y;
                I=x-1;
                J=y-1;
                display[I][J]=0;
            }
        else
            {
                I=x-1;
                J=y-1;
                display[I][J]=0;
            }
        cout<<endl;
        
        do{
           random=(rand()%25);
           if (cases[random]!=0)
           {
               cout<<"This case held $"<<cases[random]<<endl;
               cases[random]=0;
           }
        }while (random==0);
        
        tot_left--;
        
        if (tot_left==(tot_left_par-pick_par))
        {cout<<"Looks like the banker is calling...\n";}
        else
        { 
            cout<<"Here are the cases left\n";
            
            for (i=0;i<=5;i++)
            {
                for(j=0;j<=5;j++)
                {
                    if (i==0)
                    {
                        if (j==0)
                        {cout<<"  ";}
                        else 
                        {cout<<j<<" ";}
                    }
                    else
                    {
                        if (j==0)
                        {cout<<i<<" ";}
                        else
                        {
                            if(display[i-1][j-1]==1)
                            {cout<<"$ ";}
                            else
                            {cout<<"X ";}
                        }
                    }
        };
        cout<<endl;
    };
        }
    } while (tot_left>(tot_left_par-pick_par));
   
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
