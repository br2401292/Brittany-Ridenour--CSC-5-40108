/* 
  File:   Midterm Problem 5
  Author: Brittany Ridenour
  Created on January 27, 2017, 12:15 PM
  Purpose: Determine gross pay for employees
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double hrs, rate, gross;
    //Input values
    cout<<"Enter the number of hours worked: ";
    cin>>hrs;
    cout<<"Enter your hourly rate of pay: ";
    cin>>rate;
    
    if (hrs<=20)
    {
        gross=rate*hrs;
    }
    else if (hrs>20)
    {
        if (hrs<40)
        {
            gross=(20*rate)+((hrs-20)*2*rate);
        }
        else
        {
            gross=(20*rate)+(40*rate)+((hrs-40)*3*rate);
        }
    }
    cout<<"Your gross pay is $"<<gross<<endl;
    
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}