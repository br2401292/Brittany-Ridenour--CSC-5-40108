/* 
  File:  Midterm Problem 1
  Author: Brittany Ridenour
  Created on January , 2017, 10:36 PM
  Purpose:  Input a number and program will output an x shape comprised of the
 * number in descending or ascending order.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int i, j, n;
    
    //Input values
    cout<<"Please enter a number: ";
    cin>>n;
    
    if (n%2==0)
    {
        for(i=1;i<=(n-1);i++)
        {
            for(j=1;j<=n; j++)
            {
                if(j<=(n/2))
                {
                    if(i==j || i==(n-j))
                    {
                        cout<<j;
                    }
                    else
                    {
                        cout<<" ";
                    }
                }
                else if (j>(n/2))
                {
                    if(i==(j-1)|| i==(n-j+1))
                    {
                        cout<<j;
                    }
                    else
                    {
                        cout<<" ";
                    }
                }
                
            };
            cout<<endl;
        };
      
        
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
              if(i==j)
              {
                  cout<<n-i+1;
              }
              else if (j==(n-i+1))
              {
                  cout<<i;
              }
              else
              {
                  cout<<" ";
              }
            };
            cout<<endl;
        };
    }
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
