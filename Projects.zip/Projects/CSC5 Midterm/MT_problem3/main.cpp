/* 
  File:  Midterm Problem3
  Author: Brittany Ridenour
  Created on January 27, 2017, 3:53 PM
  Purpose:  User enters the date, payee, amount, and account holder for a check
 * and the program outputs the given information in a check format.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int amount;
    string date, payfirst, paylast, acctfirst, acctlast;
    
    //Input values
    cout<<"Please enter the following information\n";
    cout<<"Date: ";
    cin>>date;
    cout<<"Name of the Payee: ";
    cin>>payfirst>>paylast;
    cout<<"Amount of the check: $";
    cin>>amount;
    cout<<"Name of the account holder: ";
    cin>>acctfirst>>acctlast;
    cout<<acctfirst<<" "<<acctlast<<endl;
    cout<<"Street Address\n";
    cout<<"City, State  Zip             Date: "<<date<<endl;
    cout<<"Pay to the Order of: "<<payfirst<<" "<<paylast<<"     $"<<amount<<".00\n";
    
    cout<<" and no/100s Dollars\n";
    cout<<"Bank of CSC5\n";
    cout<<"For: Pay the rent                "<<acctfirst<<" "<<acctlast<<endl;
    
    
     
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}