/* 
  File:  Midterm Problem 4
  Author: Brittany Ridenour
  Created on January 27, 2017, 8:15 PM
  Purpose:  User enters the type of ISP package they have and # of hours used,
 * program outputs monthly bill
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char package;
    int hr_used;
    double cost;
    //Input values
    cout<<"Enter the number of hours of access used: ";
    cin>>hr_used;
    cout<<"Enter the type of package you have (1, 2, or 3): ";
    cin>>package;
    
    if (package==1)
    {
        if(hr_used<=5)
            {
                cout<<"Your bill is $16.75\n";
            }
        else if (hr_used>5)
        {
            if(hr_used<=20)
            {
              cost=16.75+((hr_used-5)*0.75);
              cout<<"Your bill is $"<<cost<<endl;
            }
            else if (hr_used>20)
            {
              cost=16.75+(15*0.75)+((hr_used-20)*1.00);
              cout<<"Your bill is $"<<cost<<endl;
            }
        }
    }
    else if (package==2)
    {
            if (hr_used<=15)
            {
                cout<<"Your bill is $23.75\n";
            }
            else if (hr_used>15)
            {
                if (hr_used<=25)
                {
                cost=23.75+((hr_used-15)*0.55);
                cout<<"Your bill is $"<<cost<<endl;
                }
                else if (hr_used>25)
                {
                    cost=23.75+(10*0.55)+((hr_used-25)*0.70);
                    cout<<"Your bill is $"<<cost<<endl;
                }
            }
    }
    else if (package==3)
    {
            cout<<"Your bill is $29.95\n";
    }
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}