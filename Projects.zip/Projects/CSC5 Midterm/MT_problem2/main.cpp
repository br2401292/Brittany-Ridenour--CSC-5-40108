/* 
  File:   Midterm Problem 2
  Author: Brittany Ridenour
  Created on January 27, 2017, 1:15 PM
  Purpose:  User enters a 4 digit number and program will out put the number
 * backwards with as many astrisks next to each digit.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
void asterisk(char& par);//Function reads the string character and out puts a 
//string with the correct amount of asterisks.

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char int1,int2,int3,int4;
    int i,j;
    
    //Input values
    cout<<"Please enter a four-digit number: ";
    cin>>int1>>int2>>int3>>int4;
    cout<<int4<<" ";
    asterisk(int4);
    cout<<int3<<" ";
    asterisk(int3);
    cout<<int2<<" ";
    asterisk(int2);
    cout<<int1<<" ";
    asterisk(int1);
    
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
void asterisk(char& par)
{
    if(par=='1')
    {
        cout<<"*\n";
    }
    else if (par=='2')
    {
        cout<<"**\n";
    }
    else if (par=='3')
    {
        cout<<"***\n";
    }
    else if (par=='4')
    {
        cout<<"****\n";
    }
    else if (par=='5')
    {
        cout<<"*****\n";
    }
    else if (par=='6')
    {
        cout<<"******\n";
    }
    else if (par=='7')
    {
        cout<<"*******\n";
    }
    else if (par=='8')
    {
        cout<<"********\n";
    }
    else if (par=='9')
    {
        cout<<"*********\n";
    }
    else
    {
        cout<<"?\n";
    }
    return;
}