/* 
  File:  Midterm Problem3
  Author: Brittany Ridenour
  Created on January 27, 2017, 3:53 PM
  Purpose:  User enters the date, payee, amount, and account holder for a check
 * and the program outputs the given information in a check format.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

void amt_hund(int amt_par);
void amt_tens(int amt_par);
void amt_ones(int amt_par);// Function takes a number between 1 and 1999 and
//outputs the number in written form
int tensplace(int amt_par);
//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int amount, thou, hund, tens, ones;
    string date, payfirst, paylast, acctfirst, acctlast;
    
    thou=amount/1000;
    hund=(amount-(thou*1000))/10;
    tens=(amount-(thou*1000)-(hund*100))/10;
    ones=(amount-(thou*1000)-(hund*100)-(tens*10));
    //Input values
    
    cout<<"Please enter the following information\n";
    cout<<"Date: ";
    cin>>date;
    cout<<"Name of the Payee: ";
    cin>>payfirst>>paylast;
    cout<<"Amount of the check: $";
    cin>>amount;
    cout<<"Name of the account holder: ";
    cin>>acctfirst>>acctlast;
    
    cout<<acctfirst<<" "<<acctlast<<endl;
    cout<<"Street Address\n";
    cout<<"City, State  Zip             Date: "<<date<<endl;
    cout<<"Pay to the Order of: "<<payfirst<<" "<<paylast<<"     $"<<amount<<".00\n";
    
    if (amount>=1000)
    { 
        cout<<"One Thousand ";
        if (hund==1)
        {
            cout<<"One Hundred ";
        }
        else if (hund==2)
        {
            cout<<"Two Hundred ";
        }
        else if (hund==3)
        {
            cout<<"Three Hundred ";
        }
        else if (hund==4)
        {
            cout<<"Four Hundred ";
        }
        else if (hund==5)
        {
            cout<<"Five Hundred ";
        }
        else if (hund==6)
        {
            cout<<"Six Hundred ";
        }
        else if (hund==7)
        {
            cout<<"Seven Hundred ";
        }
        else if (hund==8)
        {
            cout<<"Eight Hundred ";
        }
        else if (hund==9)
        {
            cout<<"Nine Hundred ";
        }
    }
    else
    {
        cout<<"";
    }
       if (hund==1)
        {
            cout<<"One Hundred ";
        }
        else if (hund==2)
        {
            cout<<"Two Hundred ";
        }
        else if (hund==3)
        {
            cout<<"Three Hundred ";
        }
        else if (hund==4)
        {
            cout<<"Four Hundred ";
        }
        else if (hund==5)
        {
            cout<<"Five Hundred ";
        }
        else if (hund==6)
        {
            cout<<"Six Hundred ";
        }
        else if (hund==7)
        {
            cout<<"Seven Hundred ";
        }
        else if (hund==8)
        {
            cout<<"Eight Hundred ";
        }
        else if (hund==9)
        {
            cout<<"Nine Hundred ";
        }
    if(tens==1)
    {
        if (ones==0)
            {
                cout<<"Ten ";
            }
        else if (ones==1)
            { cout<<"Eleven ";
            }
        else if (ones==2)
            { cout<<"Twelve ";
            }
        else if (ones==3)
            {cout<<"Thirteen ";
            }
        else if (ones==4)
            { cout<<"Fourteen ";
            }
        else if (ones==5)
            { cout<<"Fifteen ";
            }
        else if (ones==6)
            { cout<<"Sixteen ";
            }
        else if (ones==7)
            { cout<<"Seventeen ";
            }
        else if (ones==8)
            { cout<<"Eighteen ";
            }
        else if (ones==9)
        {
            cout<<"Nineteen ";
        }
    }

   
    
    
    cout<<" and no/100s Dollars\n";
    cout<<"Bank of CSC5\n";
    cout<<"For: Pay the rent                "<<acctfirst<<" "<<acctlast<<endl;
    
    
     
    //Process by mapping inputs to outputs
    
    //Output values

    //Exit stage right!
    return 0;
}
int tensplace(int amt_par)
{
    int thou, hund, tens;
    thou=amt_par/1000;
    hund=(amt_par-(thou*1000))/10;
    tens=(amt_par-(thou*1000)-(hund*100))/10;
    return(tens);
}


void amt_hund(int amt_par)
{
    int hund, thou;
    thou=amt_par/1000;
    hund=(amt_par-(thou*1000))/10;
    
        if (hund==1)
        {
            cout<<"One Hundred ";
        }
        else if (hund==2)
        {
            cout<<"Two Hundred ";
        }
        else if (hund==3)
        {
            cout<<"Three Hundred ";
        }
        else if (hund==4)
        {
            cout<<"Four Hundred ";
        }
        else if (hund==5)
        {
            cout<<"Five Hundred ";
        }
        else if (hund==6)
        {
            cout<<"Six Hundred ";
        }
        else if (hund==7)
        {
            cout<<"Seven Hundred ";
        }
        else if (hund==8)
        {
            cout<<"Eight Hundred ";
        }
        else if (hund==9)
        {
            cout<<"Nine Hundred ";
        }
     return;
}

void amt_tens(int amt_par)
{
    int tens, hund, thou, rmnd;
    thou=amt_par/1000;
    hund=(amt_par-(thou*1000))/10;
    tens=(amt_par-(thou*1000)-(hund*100))/10;
    rmnd=amt_par-(thou*1000)-(hund*100);
    
    
    
    if (tens==1)
    {
            if (rmnd==10)
            {
                cout<<"Ten ";
            }
            else if (rmnd==11)
            { cout<<"Eleven ";
            }
            else if (rmnd==12)
            { cout<<"Twelve ";
            }
            else if (rmnd==13)
            {cout<<"Thirteen ";
            }
            else if (rmnd==14)
            { cout<<"Fourteen ";
            }
            else if (rmnd==15)
            { cout<<"Fifteen ";
            }
            else if (rmnd==16)
            { cout<<"Sixteen ";
            }
            else if (rmnd==17)
            { cout<<"Seventeen ";
            }
            else if (rmnd==18)
            { cout<<"Eighteen ";
            }
            else if (rmnd==19)
            {cout<<"Nineteen ";
            }
    }
    else
    {
        switch(tens)
        {
        case 2:
            cout<<"Twenty ";
            break;
        case 3:
            cout<<"Thirty ";
            break;
        case 4:
            cout<<"Forty ";
            break;
        case 5:
            cout<<"Fifty ";
            break;
        case 6:
            cout<<"Sixty ";
            break;
        case 7:
            cout<<"Seventy ";
            break;
        case 8:
            cout<<"Eighty ";
            break;
        case 9:
            cout<<"Ninety ";
            break;    
        }
    }
    return;
}

void amt_ones(int amt_par)
{
   int ones, tens, hund, thou;
    
    thou=amt_par/1000;
    hund=(amt_par-(thou*1000))/10;
    tens=(amt_par-(thou*1000)-(hund*100))/10;
    ones=(amt_par-(thou*1000)-(hund*100)-(tens*10)); 
    
    switch (ones)
        {
            case 1:
                cout<<"One";
                break;
            case 2:
                cout<<"Two";
                break;
            case 3:
                cout<<"Three";
                break;
            case 4:
                cout<<"Four";
                break;
            case 5:
                cout<<"Five";
                break;
            case 6:
                cout<<"Six";
                break;
            case 7:
                cout<<"Seven";
                break;
            case 8:
                cout<<"Eight";
                break;
            case 9:
                cout<<"Nine";
                break;
        }
    return;
}
