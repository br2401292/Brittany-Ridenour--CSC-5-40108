/* 
  File:   Lab Assignment 3
  Author: Brittany Ridenour
  Created on January 13, 2017, 6:55 PM
  Purpose:  Write a program to calculate the percentage of the Federal budget
 * spent by the military and NASA and also calculate the debt per person for 
 * 2008 and 2016.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float mil_perc, nasa_perc, dpp08, dpp16;
    float total_budg, mil_budg, nasa_budg;
    float pop08, pop16, debt08, debt16;
    
    //Input values
    total_budg=3.54E12;
    mil_budg=5.8E11;
    nasa_budg=1.85E10;
    pop08=3.04E8;
    pop16=3.22E8;
    debt08=9.7E12;
    debt16=2.0E13;
    
    //Process by mapping inputs to outputs
    mil_perc=(mil_budg/total_budg)*100;
    nasa_perc=(nasa_budg/total_budg)*100;
    dpp08=debt08/pop08;
    dpp16=debt16/pop16;
    //Output values
    cout<< "The Federal budget is $"<<total_budg<<" per year and the military's";
    cout<<" budget of $"<<mil_budg<<" accounts for "<<mil_perc<<"% of the total.\n";
    cout<<"NASA has a yearly budget of $"<<nasa_budg<<" that accounts for "<<nasa_perc;
    cout<<"% of the total Federal budget.\n";
    
    cout<<"Based on the federal debt of $"<<debt08<<" in 2008 and population of "<<pop08;
    cout<<", the debt per person in 2008 was $"<<dpp08<<".\n";
    cout<<"In 2016 the federal debt had risen to $"<<debt16<<" and the population had grown ";
    cout<<"to "<<pop16<<". The new debt per person as of 2016 is $"<<dpp16<<".\n";
    
    //Exit stage right!
    return 0;
}