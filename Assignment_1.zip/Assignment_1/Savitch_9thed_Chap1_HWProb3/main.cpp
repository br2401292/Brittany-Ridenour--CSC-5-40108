/* 
  File:   Chapter 1 HW Problem 3
  Author: Brittany Ridenour
  Created on January 10, 2017, 11:52 AM
  Purpose:  User enters number of quarters, dimes, and nickels and program 
 * outputs the total value in cents
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int q, Q, d, D, n, N, total;
    
    //Input values
    cout<< "Press the return key after each entry.\n";
    cout<< "How many quarters do you have?\n";
    cin>> q;
    Q=25*q;
    cout<< "How many dimes do you have?\n";
    cin>> d;
    D=10*d;
    cout<< "How many nickels do you have?\n";
    cin>> n;
    N=5*n;
    //Process by mapping inputs to outputs
    total=N+D+Q;
    //Output values
    cout<< "In total, you have ";
    cout<< total;
    cout<< " cents.\n";
    
    //Exit stage right!
    return 0;
}