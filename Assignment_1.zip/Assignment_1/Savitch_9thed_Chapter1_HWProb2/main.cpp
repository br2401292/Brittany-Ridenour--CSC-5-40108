/* 
  File:   Chapter 1 Hw Problem 2
  Author: Brittany Ridenour
  Created on January 9, 2017, 11:33 PM
  Purpose: Write a program that prints out “C S !” in large block letters 
 * inside a border of *s followed by two blank lines then the message 
 * Computer Science is Cool Stuff.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char c, s;
    
    //Input values
    c='c';
    s='s';
    //Process by mapping inputs to outputs
    cout << "***************************************"<<endl;
    cout <<"      " <<c<<c<<c<< "         " <<s<<s<<s<<s<<"      !!"<<endl;
    cout << "   "<<c<<"      "<<c<<"     "<<s<<"      "<<s<<"    !!"<<endl;
    cout << "  "<<c<<"            "<<s<<"            !!"<<endl;
    cout << " "<<c<<"              "<<s<<"           !!"<<endl;
    cout << " "<<c<<"               "<<s<<s<<s<<s<<"       !!"<<endl;
    cout << " "<<c<<"                     "<<s<<"    !!"<<endl;
    cout << "  "<<c<<"                     "<<s<<"   !!"<<endl;
    cout << "   "<<c<<"     "<<c<<"       "<<s<<"      "<<s<<endl;
    cout << "     "<<c<<c<<c<<"          "<<s<<s<<s<<s<<"      00"<<endl;
    cout << "****************************************"<<endl;
    cout << "Computer science is cool stuff!"<<endl;
    
    //Output values

    //Exit stage right!
    return 0;
}