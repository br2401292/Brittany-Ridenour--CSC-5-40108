/* 
  File:   Chapter 1 HW Problem 10
  Author: Brittany Ridenour
  Created on January 10, 2017, 1:11 PM
  Purpose:  User inputs the width and length of a rectangular area and program 
 * will output the total length of fence needed to enclose the area.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int width, length, totalLength;
    //Input values
   

    //Process by mapping inputs to outputs
    cout<< "Hello, please enter the width of the area to be fenced in:\n";
    cin>> width;
    cout<< "Please enter the length of the area:\n";
    cin>> length;
    totalLength=width+width+length+length;
    cout<< "You will need ";
    cout<< totalLength;
    cout<< " feet of fence to enclose an area with width of ";
    cout<< width;
    cout<< " feet and length of ";
    cout<< length;
    cout<< " feet.\n";
    //Output values

    //Exit stage right!
    return 0;
}