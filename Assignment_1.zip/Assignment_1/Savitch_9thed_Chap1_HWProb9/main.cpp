/* 
  File:   Chapter 1 Hw Problem 9
  Author: Brittany Ridenour
  Created on January 10, 2017, 1:07 PM
  Purpose: Modify pea pod program from HW problem 6 and change multiplication 
 * operator do addition. Program will run without error but output value will
 * be incorrect because of logic error.
 */
//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int number_of_pods, peas_per_pod, total_peas;
    
    //Input values
    
    //Process by mapping inputs to outputs
    cout<< "Press return after entering a number.\n";
    cout<< "Enter the number of pods:\n";
    cin>> number_of_pods;
    cout<< "Enter the number of peas in a pod:\n";
    cin>> peas_per_pod;
    total_peas = number_of_pods+peas_per_pod;
    cout<< "If you have ";
    cout<< number_of_pods;
    cout<< " pea pods\n";
    cout<< "and ";
    cout<< peas_per_pod;
    cout<< " peas in each pod, then\n";
    cout<< "you have ";
    cout<< total_peas;
    cout<< " peas in all all the pods.\n";
    
    //Output values

    //Exit stage right!
    return 0;
}