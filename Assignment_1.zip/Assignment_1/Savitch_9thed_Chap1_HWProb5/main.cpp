/* 
  File:  Chapter 1 HW Problem 5
  Author: Dr. Brittany Ridenour
  Created on January 10, 2017, 12:26 PM
  Purpose:  User inputs any letter and program will output a large C composed
 * of the given letter
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char c;
    
    //Input values
    cout<< "Pick a letter.\n";
    cin>> c;
    
    //Process by mapping inputs to outputs
    
    //Output values
    cout<<"   "<<c<<c<<c<<endl;
    cout<<" "<<c<<"     "<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<" "<<c<<"     "<<c<<endl;
    cout<<"   "<<c<<c<<c<<endl;
    

    //Exit stage right!
    return 0;
}